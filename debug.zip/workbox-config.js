// module.exports = {
//   "globDirectory": "build/",
//   "globPatterns": [
//     "**/*.{json,ico,html,png,js,txt,css,jpg,svg,ttf}"
//   ],
//   "swDest": "build/sw.js",
//   "swSrc":"src/sw.js",
//   "inejctionPointRegexp":/(const precacheManifest= )\[\](;)/
// };